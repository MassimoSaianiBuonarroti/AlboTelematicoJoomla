<?php

defined('_JEXEC') or die;

use Joomla\CMS\Filesystem\Folder;

class Com_AlbotelematicoInstallerScript
{
    public function install($parent): bool
    {
        return $this->ensureAttachmentFolder();
    }

    public function update($parent): bool
    {
        return $this->ensureAttachmentFolder();
    }

    private function ensureAttachmentFolder(): bool
    {
        $path = JPATH_ROOT . '/images/albo_atti';

        if (!Folder::exists($path)) {
            return Folder::create($path);
        }

        return true;
    }
}
